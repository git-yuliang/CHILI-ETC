# CHILI-ETC
CHILI-Exposure Time Calculator, ETC
This code is used for setting the CHILI exposure time parameters.
by YuLiang 
yuliang@shao.ac.cn

This work is based on the work of the predecessors(by Lin Lin@SHAO: https://ifs-etc.readthedocs.io/en/latest/quickstart.html), 
and has been modified and completed on the basis of it.
